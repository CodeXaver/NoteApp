package com.example.coddexaver.andronote;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Content extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_content);
    }
}
